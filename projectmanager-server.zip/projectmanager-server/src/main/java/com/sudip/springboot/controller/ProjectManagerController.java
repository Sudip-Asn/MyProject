package com.sudip.springboot.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sudip.springboot.Application;
import com.sudip.springboot.bo.ParentTaskVO;
import com.sudip.springboot.bo.ProjectVO;
import com.sudip.springboot.bo.TaskVO;
import com.sudip.springboot.bo.UserVO;
import com.sudip.springboot.service.ProjectManagerService;

@RestController
public class ProjectManagerController {
	
	private static final Logger LOGGER = LogManager.getLogger(ProjectManagerController.class);
	private ProjectManagerService projectManagerService;

	@Autowired
	public ProjectManagerController(ProjectManagerService projectManagerService) {
		this.projectManagerService = projectManagerService;
	}

	@GetMapping("/home")
	public String home() {
		return "forward:/index.html";
	}
	
	@GetMapping("/test")
	public String testhome() {
		return "Project Manager App - Creator: Mani, Vignesh Suryah";
	}
	
	
	@GetMapping("/api/tasks")
	public List<TaskVO> getTasks() {
		List<TaskVO> tasks = null;
		try{
			tasks = projectManagerService.retriveTasks();
		}catch(Exception e){
			LOGGER.error("Exception Occured in Get Tasks");
		}
		
		return tasks;
	}
	
	@PostMapping(path = "/api/tasks", consumes = "application/json", produces = "application/json")
	public boolean updateTask(@RequestBody TaskVO task) {
		try {
			projectManagerService.updateTask(task); 
		}catch(Exception e)
		{
			LOGGER.error("Exception Occured in Update Task");
			return false;
		}
		return true;
	}
	
	
	@GetMapping("/api/parenttasks")
	public List<ParentTaskVO> getAllParentTasks() {
		List<ParentTaskVO> tasks = projectManagerService.retriveParentTasks();
		return tasks;
	}
	
	@GetMapping("/api/parenttasks/projects/{projectId}")
	public List<ParentTaskVO> getParentTasksForProjectId(@PathVariable(name="projectId") String projectId) {
		List<ParentTaskVO> tasks = null;
		try{
			tasks = projectManagerService.retriveParentTasksForProjectId(projectId); 
		}catch(Exception e){
			LOGGER.error("Exception Occured in Get Parent Task");
		}
		
		return tasks;
	}
	
	@PostMapping(path = "/api/parenttasks", consumes = "application/json", produces = "application/json")
	public boolean updateParentTask(@RequestBody ParentTaskVO parentTask) {
		try {
			projectManagerService.updateParentTask(parentTask);
		}catch(Exception e)
		{
			LOGGER.error("Exception Occured in Update Parent Task");
			return false;
		}
		return true;
	}
	
	
	@GetMapping("/api/projects")
	public List<ProjectVO> getProjects() {
		List<ProjectVO> projects = projectManagerService.retriveProjects();
		return projects;
	}
	
	@PostMapping(path = "/api/projects", consumes = "application/json", produces = "application/json")
	public boolean updateProject(@RequestBody ProjectVO project) {
		try {
			projectManagerService.updateProject(project);
		}catch(Exception e)
		{
			LOGGER.error("Exception Occured in Update Project");
			return false;
		}
		return true;
	}
	
	
	@GetMapping("/api/users")
	public List<UserVO> getUsers() {
		List<UserVO> users = null;
		try{
			users = projectManagerService.retriveUsers();
		}catch(Exception e){
			LOGGER.error("Exception Occured in Get Users");
		}
		
		return users;
	}
	
	@PostMapping(path = "/api/users", consumes = "application/json", produces = "application/json")
	public boolean updateUsers(@RequestBody UserVO user) {
		try {
			projectManagerService.updateUser(user);
		}catch(Exception e)
		{
			LOGGER.error("Exception Occured in Update User");
			return false;
		}
		return true;
	}
	
	
}
